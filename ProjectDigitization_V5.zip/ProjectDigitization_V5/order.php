<?php


$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];
$date = date('H:i, jS F, Y');
// OUTPUT TO TEXT FILE--------------------------------------------------------------------------
$outputstring = 
"Customer Name: " .$name. "\n" .
"Email: " .$email. "\n" .
"Message: " .$message. "\n" .
"Date Processed: " .$date. "\n \n \n" .


//OPEN FILE FOR APPENDING-------------------------------------------------------------------------------------------------
@$fp = fopen("C:/xampp/htdocs/ProjectDigitization_V4/contactmessages.txt", 'ab');

//if (!$fp) {
    //echo "<p><strong> Your order could not be processed at this time. Please try again
   // later.</strong></p>";
  //  exit;
//}

flock($fp, LOCK_EX);
fwrite($fp, $outputstring, strlen($outputstring));
flock($fp, LOCK_UN);
fclose($fp);

?>