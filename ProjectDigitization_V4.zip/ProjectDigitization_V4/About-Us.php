<?php 
    include('functions.php');
    //if not logged in, redirected to login.php
    if (!isLoggedIn()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
    }
?>

<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>About Us</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="About-Us.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 2.29.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,990i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    
    
    
    
        
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Site2",
		"url": "index.html",
		"sameAs": []
}</script>
    <meta property="og:title" content="About Us">
    <meta property="og:type" content="website">
    <meta name="theme-color" content="#ff5126">
    <link rel="canonical" href="index.html">
    <meta property="og:url" content="index.html">
  </head>
  <body class="u-body"><header class="u-align-left u-clearfix u-header u-valign-middle u-header" id="sec-ae7a"><div class="u-black u-border-2 u-border-black u-container-style u-expanded-width u-group u-shape-rectangle u-group-1">
        <div class="u-container-layout u-container-layout-1">
          <nav class="u-menu u-menu-one-level u-offcanvas u-menu-1">
            <div class="menu-collapse" style="font-size: 1.875rem; letter-spacing: 0px; text-transform: uppercase; font-weight: 700;">
              <a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="#">
                <svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol id="menu-hamburger" viewBox="0 0 16 16" style="width: 16px; height: 16px;"><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</symbol>
</defs></svg>
              </a>
            </div>
            <div class="u-custom-menu u-nav-container">
              <ul class="u-nav u-spacing-2 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="homepage.php" style="padding: 38px 88px;">Home</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="Menu.php" style="padding: 38px 88px;">Menu</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="About-Us.php" style="padding: 38px 88px;">About Us</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="Contact-Us.php" style="padding: 38px 88px;">Contact Us</a>
</li>
<li class="u-nav-item">

<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
			

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="index.php?logout='1'" style="color: red;">Logout</a>
					</small>

				<?php endif ?>

            </div>

            </li>
</ul>


            <div class="u-custom-menu u-nav-container-collapse">
              <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
                <div class="u-sidenav-overflow">
                  <div class="u-menu-close"></div>
                  <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="homepage.php" style="padding: 38px 88px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Menu.php" style="padding: 38px 88px;">Menu</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="About-Us.php" style="padding: 38px 88px;">About Us</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Contact-Us.php" style="padding: 38px 88px;">Contact Us</a>
</li>
<li class="u-nav-item">

<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
			

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="index.php?logout='1'" style="color: red;">Logout</a>
					</small>

				<?php endif ?>

            </div>

            </li>
</ul>
                </div>
              </div>
              <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
            </div>
          </nav>
        </div>
      </div></header>
    <section class="u-align-center u-clearfix u-image u-shading u-section-1" src="" data-image-width="1600" data-image-height="1066" id="sec-5b5d">
      <div class="u-clearfix u-sheet u-sheet-1">
        <h1 class="u-text u-text-default u-title u-text-1">About Us</h1>
      </div>
    </section>
    <section class="u-clearfix u-section-2" id="sec-3f9c">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-container-style u-expanded-width-sm u-expanded-width-xs u-group u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <h2 class="u-text u-text-1">ICS 370-01</h2>
            <p class="u-text u-text-2">In Software Design Models, ICS 370, we are tasked to create a website. We go through the agile process in making this website by actively communicating and adapting the website to the client's needs.</p>
          </div>
        </div>
        <div class="u-clearfix u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-container-style u-layout-cell u-left-cell u-size-60 u-layout-cell-1" src="">
                <div class="u-container-layout u-valign-middle u-container-layout-2">
                  <img src="images/nuqPA2Du_400x400.png" alt="" class="u-image u-image-default u-image-1" data-image-width="358" data-image-height="358">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-align-center u-clearfix u-section-3" id="sec-5cbe">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-expanded-width u-list u-repeater u-list-1">
          <div class="u-align-center u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1"><span class="u-icon u-icon-circle u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 128 128" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-48d5"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 128 128" id="svg-48d5"><path d="m93.8 13.5 18.4 25.2h-5.7c-2 0-3.6 1.6-3.6 3.6v77.7h-18.3v-77.7c0-2-1.6-3.6-3.6-3.6h-5.7l18.5-25.2m-22.4 55.6c3.3 0 6 2.7 6 6.1v44.8h-18.4v-44.8c0-3.3 2.7-6.1 6-6.1h6.4m-25.5 19.4c3.3 0 6 2.7 6 6.1v25.4h-18.4v-25.5c0-3.3 2.7-6.1 6-6.1h6.4m-25.6 19.4c3.3 0 6 2.7 6 6.1v6.1h-18.4v-6.1c0-3.3 2.7-6.1 6-6.1h6.4m73.5-107.8-6.4 8.7-18.4 25.2-9.4 12.8h17.1v15.4c-1.6-0.7-3.4-1-5.2-1h-6.5c-7.7 0-13.9 6.3-13.9 14.1v6.3c-1.6-0.7-3.4-1-5.2-1h-6.4c-7.7 0-13.9 6.3-13.9 14.1v6.3c-1.6-0.7-3.4-1-5.2-1h-6.4c-7.7-0.1-14 6.2-14 14v14.1h110.9v-81.3h17.1l-9.4-12.8-18.4-25.2-6.4-8.7z"></path></svg></span>
              <h3 class="u-text u-text-1">Effective</h3>
              <p class="u-text u-text-2">Allows the cashiers to know exactly what you ordered before you get to the register</p>
            </div>
          </div>
          <div class="u-align-center u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-valign-top u-container-layout-2"><span class="u-icon u-icon-circle u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 128 128" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-f8c3"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 128 128" id="svg-f8c3"><polygon points="104 40 104 48 120 48 120 120 48 120 48 104 40 104 40 128 128 128 128 40"></polygon><rect x="80" width="8" height="8"></rect><rect x="16" width="8" height="8"></rect><rect x="32" width="8" height="8"></rect><rect x="16" y="80" width="8" height="8"></rect><rect x="48" width="8" height="8"></rect><rect x="64" width="8" height="8"></rect><rect width="8" height="8"></rect><rect y="48" width="8" height="8"></rect><rect y="64" width="8" height="8"></rect><rect y="32" width="8" height="8"></rect><rect y="16" width="8" height="8"></rect><rect x="80" y="16" width="8" height="8"></rect><rect y="80" width="8" height="8"></rect><path d="m63.6 96.8 10.4 10.4 36.8-36.8-10.6-10.6-5.7-17-19.6-19.5-39.5 16.2c-6.1 2.5-9.1 9.5-6.5 15.7l0.3 0.6-0.5 0.5c-6.2 6.2-6.2 16.4 0 22.6l15.1 15.1 19.8 2.8zm-31.6-29.2c0-2.1 0.8-4.2 2.3-5.7l14.1 14.1 5.7-5.7-17-17c-1.6-1.6-1.6-4.1 0-5.7 0.4-0.4 0.8-0.7 1.3-0.9l34.6-14 14.4 14.4 5.7 17 6.3 6.3-25.5 25.5-6.6-6.6-19.8-2.8-13.2-13.3c-1.5-1.5-2.3-3.5-2.3-5.6z"></path></svg></span>
              <h3 class="u-text u-text-3">Simple</h3>
              <p class="u-text u-text-4">A simple ebsite design for usability and functionality</p>
            </div>
          </div>
          <div class="u-align-center u-container-style u-list-item u-repeater-item">
            <div class="u-container-layout u-similar-container u-valign-top u-container-layout-3"><span class="u-icon u-icon-circle u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 128 128" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-10bb"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 128 128" id="svg-10bb"><path d="m119.4 104.8-17.8-30.8c1.6-1.3 2.5-3.4 2.4-5.6l-1.3-10.7 7.4-7.6c2.3-2.3 2.4-6.1 0.2-8.8l-7.4-7.9 1.5-10.8c0.3-3.2-2-6.4-5.2-7l-10.7-2.1-5.2-9.4c-1.1-2.2-3.3-3.5-5.8-3.5-0.8 0-1.5 0.1-2.3 0.4l-10.4 4.4-9.6-4.6c-0.9-0.5-1.9-0.7-3-0.7-0.6 0-1.3 0.1-1.9 0.3-1.6 0.5-2.9 1.5-3.8 3l-5.3 9.4-10.7 1.9c-3.4 0.6-5.7 3.7-5.4 7.1l1.3 10.7-7.4 7.6c-2.3 2.3-2.4 6.1-0.2 8.8l7.4 7.9-1.5 10.8c-0.3 2.3 0.8 4.6 2.7 5.9l-17.9 31.3c-0.7 1.1-0.7 2.6-0.1 3.9v0.1l0.1 0.1c0.8 1.2 2 1.9 3.4 1.9h19.2l8.7 14.9c0.8 1.2 2 1.9 3.4 1.9s2.8-0.8 3.5-2l16.6-27.9 16.8 28.3c0.8 1.2 2 1.9 3.4 1.9s2.8-0.8 3.5-2l8.7-15.3h19.2c1.4 0 2.7-0.8 3.4-1.9 0.9-1.1 0.9-2.7 0.1-3.9zm-34.9 11.3-17.9-30.5 7.4 3.6c0.9 0.4 1.8 0.6 2.9 0.6 2.4 0 4.6-1.2 5.7-3.2l5.3-9.4 5.8-1 15.4 26.6h-14.7c-1.4 0-2.8 0.8-3.5 2l-6.4 11.3zm-40-0.3-6.5-11c-0.8-1.2-2-1.9-3.4-1.9h-14.8l15.5-27 5.4 0.9 5.2 9.3c1.1 2.2 3.3 3.5 5.8 3.5 0.8 0 1.5-0.1 2.3-0.4l0.5-0.1 3.9-1.8 1.4 2.4-15.3 26.1zm-11.9-78.1c1.4-1.4 2.1-3.4 1.8-5.3l-1.2-10 10.2-1.8c1.9-0.3 3.6-1.6 4.6-3.2l4.9-8.8 9 4.3c0.9 0.5 1.9 0.7 2.9 0.7s2-0.2 2.9-0.7l9.2-4.1 4.9 9.1c1.1 1.7 2.7 2.9 4.5 3.1l10 1.9-1.4 10c-0.3 1.9 0.3 4 1.7 5.3l6.9 7.3-7 7.1c-1.5 1.4-2.1 3.4-1.8 5.3l1.2 9.9-9.9 1.6c-2 0.3-3.7 1.6-4.6 3.2l-4.9 8.8-9-4.3c-0.9-0.5-1.9-0.7-2.9-0.7s-2 0.2-2.9 0.7l-9.2 4.2-4.9-9c-1.1-1.7-2.8-2.9-4.6-3.1l-10.1-1.8 1.4-10c0.3-1.9-0.3-4-1.7-5.3l-6.8-7.4 6.8-7z"></path><path d="m64.5 71c14.7 0 26.6-11.7 26.6-26.2 0-14.4-11.9-26.2-26.6-26.2s-26.6 11.7-26.6 26.2 11.9 26.2 26.6 26.2zm0-44.4c10.2 0 18.6 8.2 18.6 18.3s-8.3 18.3-18.6 18.3c-10.2 0-18.6-8.2-18.6-18.3s8.4-18.3 18.6-18.3z"></path></svg></span>
              <h3 class="u-text u-text-5">Quality</h3>
              <p class="u-text u-text-6">A simple but sweet website that allows you to order quick and easy withouth the extra information</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-section-4" id="sec-0d9f">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-container-style u-expanded-width-md u-expanded-width-sm u-expanded-width-xs u-group u-group-1">
          <div class="u-container-layout u-container-layout-1">
            <h2 class="u-align-center u-text u-text-1">About Us: Our Team</h2>
            <p class="u-align-center u-text u-text-2">Sample text. This is the team helping to build the order form.</p>
          </div>
        </div><span class="u-icon u-icon-circle u-text-grey-40 u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512.0020141601562" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-5546"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 512 512.0020141601562" id="svg-5546"><g transform="translate(7, 0)"><path d="m198.863281 99.792969c-8.484375 0-16.921875 1.078125-25.078125 3.207031-5.34375 1.394531-8.546875 6.855469-7.152344 12.199219 1.394532 5.34375 6.859376 8.542969 12.203126 7.152343 6.507812-1.699218 13.246093-2.5625 20.027343-2.5625 43.601563 0 79.070313 35.472657 79.070313 79.070313 0 43.601563-35.472656 79.070313-79.070313 79.070313-43.597656 0-79.070312-35.46875-79.070312-79.070313 0-6.777344.859375-13.511719 2.558593-20.019531 1.394532-5.34375-1.808593-10.804688-7.152343-12.199219-5.339844-1.390625-10.808594 1.808594-12.203125 7.152344-2.125 8.152343-3.203125 16.585937-3.203125 25.066406 0 54.628906 44.445312 99.070313 99.070312 99.070313 54.628907 0 99.070313-44.441407 99.070313-99.070313 0-54.625-44.441406-99.066406-99.070313-99.066406zm0 0"></path><path d="m198.863281 257.933594c32.570313 0 59.070313-26.5 59.070313-59.070313 0-32.570312-26.5-59.070312-59.070313-59.070312-32.570312 0-59.070312 26.5-59.070312 59.070312 0 32.570313 26.5 59.070313 59.070312 59.070313zm0-98.140625c21.542969 0 39.070313 17.527343 39.070313 39.070312s-17.527344 39.066407-39.070313 39.066407-39.070312-17.523438-39.070312-39.066407 17.527343-39.070312 39.070312-39.070312zm0 0"></path><path d="m198.867188 208.863281c5.519531 0 10-4.480469 10-10 0-5.523437-4.480469-10-10-10h-.007813c-5.523437 0-9.996094 4.476563-9.996094 10 0 5.519531 4.480469 10 10.003907 10zm0 0"></path><path d="m457.148438 332.226562-26.519532-5.585937c12.308594-11.496094 20.023438-27.847656 20.023438-45.980469v-9.265625c5.347656-.199219 9.625-4.585937 9.625-9.980469 0-5.398437-4.28125-9.785156-9.632813-9.980468-.175781-31.136719-23.074219-56.980469-52.917969-61.769532v-22.277343c0-5.523438-4.480468-10-10-10h-34.796874c-3.582032-13.355469-8.878907-26.128907-15.808594-38.125l24.613281-24.617188c1.875-1.875 2.929687-4.417969 2.929687-7.070312 0-2.652344-1.054687-5.195313-2.929687-7.070313l-44.515625-44.515625c-3.90625-3.90625-10.234375-3.90625-14.140625 0l-24.617187 24.613281c-11.996094-6.925781-24.769532-12.222656-38.121094-15.804687v-34.796875c0-5.523438-4.480469-10-10-10h-62.957032c-5.519531 0-10 4.476562-10 10v34.796875c-13.351562 3.582031-26.121093 8.878906-38.117187 15.808594l-24.621094-24.617188c-3.90625-3.90625-10.234375-3.90625-14.140625 0l-44.515625 44.511719c-3.90625 3.90625-3.90625 10.238281 0 14.144531l24.617188 24.617188c-6.925781 12-12.21875 24.765625-15.800781 38.125h-34.804688c-5.519531 0-10 4.476562-10 10v62.953125c0 5.523437 4.480469 10 10 10h34.796875c3.582031 13.355468 8.878906 26.125 15.808594 38.125l-24.617188 24.613281c-1.875 1.875-2.929687 4.421875-2.929687 7.074219 0 2.648437 1.054687 5.195312 2.929687 7.070312l44.515625 44.511719c3.90625 3.90625 10.234375 3.90625 14.144532 0l24.613281-24.613281c12 6.929687 24.769531 12.226562 38.125 15.808594v34.796874c0 5.523438 4.476562 10 10 10h62.953125c5.523437 0 10-4.476562 10-10v-34.796874c13.355468-3.585938 26.125-8.878907 38.121094-15.808594l11.53125 11.527344c-8.226563 9.007812-13.3125 20.566406-13.3125 32.414062v120.941406c0 5.519532 4.476562 10 10 10 5.523437 0 10-4.480468 10-10v-120.941406c0-8.949219 5.351562-17.886719 13.246093-23.625.1875-.121094.367188-.253906.546875-.390625 3.574219-2.496094 7.636719-4.339844 11.949219-5.25l27.921875-5.878906v3.976562c0 17.148438 11.613281 31.625 27.382812 36.007813v8.738281c0 5.523437 4.476563 10 10 10 5.519532 0 10-4.476563 10-10v-8.738281c15.769532-4.382813 27.378907-18.859375 27.378907-36.007813v-3.976562l27.921875 5.878906c14.195312 2.988281 25.742187 16.117187 25.742187 29.265625v120.941406c0 5.519532 4.480469 10 10 10 5.523438 0 10-4.480468 10-10v-120.941406c0-22.472656-18.28125-43.921875-41.621093-48.835938zm-69.421876-8.636718c-23.671874 0-42.929687-19.257813-42.929687-42.929688v-9.246094h85.855469v9.246094c0 23.671875-19.257813 42.929688-42.925782 42.929688zm-10-113.539063v41.363281h-32.921874c.175781-20.058593 14.175781-36.871093 32.921874-41.363281zm52.917969 41.363281h-32.917969v-41.363281c18.742188 4.488281 32.746094 21.304688 32.917969 41.363281zm-112.34375 80.8125c-4.261719.894532-8.347656 2.351563-12.191406 4.253907l-19.074219-19.074219c-3.332031-3.332031-8.542968-3.886719-12.503906-1.324219-14.214844 9.199219-29.785156 15.660157-46.289062 19.195313-4.609376.988281-7.902344 5.0625-7.902344 9.777344v32.667968h-42.953125v-32.664062c0-4.714844-3.292969-8.792969-7.902344-9.777344-16.503906-3.539062-32.078125-9.996094-46.292969-19.195312-3.960937-2.5625-9.167968-2.007813-12.503906 1.324218l-23.113281 23.113282-30.371094-30.375 23.109375-23.109376c3.335938-3.335937 3.886719-8.546874 1.324219-12.503906-9.195313-14.21875-15.652344-29.792968-19.191407-46.292968-.988281-4.609376-5.0625-7.902344-9.777343-7.902344h-32.667969v-42.957032h32.679688c4.714843 0 8.789062-3.292968 9.777343-7.902343 3.535157-16.503907 9.992188-32.078125 19.1875-46.289063 2.558594-3.957031 2.007813-9.167968-1.328125-12.503906l-23.113281-23.113281 30.371094-30.375 23.117187 23.117187c3.335938 3.335938 8.542969 3.886719 12.503906 1.324219 14.214844-9.199219 29.789063-15.65625 46.289063-19.195313 4.605469-.988281 7.902344-5.0625 7.902344-9.777343v-32.667969h42.953125v32.667969c0 4.714843 3.292968 8.789062 7.902344 9.777343 16.503906 3.539063 32.078124 9.996094 46.292968 19.191407 3.957032 2.5625 9.167969 2.011719 12.503906-1.324219l23.109376-23.113281 30.375 30.375-23.113282 23.109375c-3.332031 3.335937-3.886718 8.546875-1.324218 12.503906 9.199218 14.214844 15.65625 29.792969 19.191406 46.292969.988281 4.609375 5.0625 7.902343 9.777344 7.902343h32.667968v12.28125c-29.847656 4.785157-52.746094 30.632813-52.917968 61.765626-5.351563.195312-9.632813 4.582031-9.632813 9.984374 0 5.394532 4.277344 9.78125 9.621094 9.980469v9.265625c0 18.128906 7.71875 34.484375 20.03125 45.976563zm69.425781 35.046876c-9.582031 0-17.378906-7.796876-17.378906-17.378907v-6.304687h34.757813v6.304687c0 9.582031-7.796875 17.378907-17.378907 17.378907zm0 0"></path><path d="m387.726562 474.640625c-5.523437 0-10 4.476563-10 10v17.359375c0 5.523438 4.476563 10 10 10 5.523438 0 10-4.476562 10-10v-17.359375c0-5.523437-4.476562-10-10-10zm0 0"></path><path d="m135.875 145.882812c2.722656 0 5.433594-1.101562 7.40625-3.273437 3.714844-4.085937 3.414062-10.410156-.671875-14.125s-10.410156-3.417969-14.125.671875l-.007813.003906c-3.714843 4.085938-3.410156 10.410156.675782 14.125 1.917968 1.742188 4.324218 2.597656 6.722656 2.597656zm0 0"></path><path d="m387.726562 429.640625c-5.523437 0-10 4.480469-10 10.003906 0 5.523438 4.476563 10 10 10 5.523438 0 10-4.476562 10-10v-.007812c0-5.523438-4.476562-9.996094-10-9.996094zm0 0"></path>
</g></svg></span>
        <div class="u-clearfix u-expanded-width u-gutter-0 u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-align-center u-container-style u-layout-cell u-left-cell u-size-15 u-size-30-md u-layout-cell-1">
                <div class="u-container-layout u-valign-top u-container-layout-2">
                  <div alt="" class="u-align-left u-image u-image-circle u-image-1" data-image-width="600" data-image-height="547"></div>
                  <h5 class="u-custom-font u-heading-font u-text u-text-3">Ken Thao</h5>
                  <p class="u-text u-text-4">Developer</p>
                </div>
              </div>
              <div class="u-align-center u-container-style u-layout-cell u-size-15 u-size-30-md u-layout-cell-2">
                <div class="u-container-layout u-valign-top u-container-layout-3">
                  <div alt="" class="u-align-left u-image u-image-circle u-image-2"></div>
                  <h5 class="u-custom-font u-heading-font u-text u-text-5">Obsa Maskalo</h5>
                  <p class="u-text u-text-6">Developer</p>
                </div>
              </div>
              <div class="u-align-center u-container-style u-layout-cell u-size-15 u-size-30-md u-layout-cell-3">
                <div class="u-container-layout u-container-layout-4">
                  <div alt="" class="u-align-left u-expanded-width u-image u-image-circle u-image-3" data-image-width="600" data-image-height="547"></div>
                  <h5 class="u-custom-font u-heading-font u-text u-text-7">Skyler Jensen</h5>
                  <p class="u-text u-text-8">Developer</p>
                </div>
              </div>
              <div class="u-align-center u-container-style u-layout-cell u-right-cell u-size-15 u-size-30-md u-layout-cell-4">
                <div class="u-container-layout u-container-layout-5">
                  <div alt="" class="u-align-left u-expanded-width u-image u-image-circle u-image-4" data-image-width="600" data-image-height="547"></div>
                  <h5 class="u-custom-font u-heading-font u-text u-text-9">Clayton Miller</h5>
                  <p class="u-text u-text-10">Developer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    <footer class="u-clearfix u-footer u-grey-80" id="sec-73b1"><div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-align-center-sm u-align-center-xs u-align-left-md u-align-left-xl u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1">
                <div class="u-container-layout u-valign-middle u-container-layout-1">
                  <p class="u-text u-text-default u-text-1">2020, Project Digitization, All Rights Reserved</p>
                </div>
              </div>
              <div class="u-align-center-sm u-align-center-xs u-align-left-md u-align-right-lg u-align-right-xl u-container-style u-layout-cell u-right-cell u-size-30 u-layout-cell-2">
                <div class="u-container-layout u-valign-middle u-container-layout-2">
                  <div class="u-social-icons u-spacing-10 u-social-icons-1">
                    <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-facebook u-social-type-logo u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-be69"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-be69"><path d="M75.5,28.8H65.4c-1.5,0-4,0.9-4,4.3v9.4h13.9l-1.5,15.8H61.4v45.1H42.8V58.3h-8.8V42.4h8.8V32.2 c0-7.4,3.4-18.8,18.8-18.8h13.8v15.4H75.5z"></path></svg></span>
                    </a>
                    <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-twitter u-social-type-logo u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-789d"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-789d"><path d="M92.2,38.2c0,0.8,0,1.6,0,2.3c0,24.3-18.6,52.4-52.6,52.4c-10.6,0.1-20.2-2.9-28.5-8.2 c1.4,0.2,2.9,0.2,4.4,0.2c8.7,0,16.7-2.9,23-7.9c-8.1-0.2-14.9-5.5-17.3-12.8c1.1,0.2,2.4,0.2,3.4,0.2c1.6,0,3.3-0.2,4.8-0.7 c-8.4-1.6-14.9-9.2-14.9-18c0-0.2,0-0.2,0-0.2c2.5,1.4,5.4,2.2,8.4,2.3c-5-3.3-8.3-8.9-8.3-15.4c0-3.4,1-6.5,2.5-9.2 c9.1,11.1,22.7,18.5,38,19.2c-0.2-1.4-0.4-2.8-0.4-4.3c0.1-10,8.3-18.2,18.5-18.2c5.4,0,10.1,2.2,13.5,5.7c4.3-0.8,8.1-2.3,11.7-4.5 c-1.4,4.3-4.3,7.9-8.1,10.1c3.7-0.4,7.3-1.4,10.6-2.9C98.9,32.3,95.7,35.5,92.2,38.2z"></path></svg></span>
                    </a>
                    <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-instagram u-social-type-logo u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-8108"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-8108"><path d="M55.9,32.9c-12.8,0-23.2,10.4-23.2,23.2s10.4,23.2,23.2,23.2s23.2-10.4,23.2-23.2S68.7,32.9,55.9,32.9z M55.9,69.4c-7.4,0-13.3-6-13.3-13.3c-0.1-7.4,6-13.3,13.3-13.3s13.3,6,13.3,13.3C69.3,63.5,63.3,69.4,55.9,69.4z"></path><path d="M79.7,26.8c-3,0-5.4,2.5-5.4,5.4s2.5,5.4,5.4,5.4c3,0,5.4-2.5,5.4-5.4S82.7,26.8,79.7,26.8z"></path><path d="M78.2,11H33.5C21,11,10.8,21.3,10.8,33.7v44.7c0,12.6,10.2,22.8,22.7,22.8h44.7c12.6,0,22.7-10.2,22.7-22.7 V33.7C100.8,21.1,90.6,11,78.2,11z M91,78.4c0,7.1-5.8,12.8-12.8,12.8H33.5c-7.1,0-12.8-5.8-12.8-12.8V33.7 c0-7.1,5.8-12.8,12.8-12.8h44.7c7.1,0,12.8,5.8,12.8,12.8V78.4z"></path></svg></span>
                    </a>
                    <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-linkedin u-social-type-logo u-icon-4"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-db5b"></use></svg><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" xml:space="preserve" class="u-svg-content" viewBox="0 0 112 112" x="0px" y="0px" id="svg-db5b"><path d="M33.8,96.8H14.5v-58h19.3V96.8z M24.1,30.9L24.1,30.9c-6.6,0-10.8-4.5-10.8-10.1c0-5.8,4.3-10.1,10.9-10.1 S34.9,15,35.1,20.8C35.1,26.4,30.8,30.9,24.1,30.9z M103.3,96.8H84.1v-31c0-7.8-2.7-13.1-9.8-13.1c-5.3,0-8.5,3.6-9.9,7.1 c-0.6,1.3-0.6,3-0.6,4.8V97H44.5c0,0,0.3-52.6,0-58h19.3v8.2c2.6-3.9,7.2-9.6,17.4-9.6c12.7,0,22.2,8.4,22.2,26.1V96.8z"></path></svg></span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div></footer>
   
  </body>
</html>