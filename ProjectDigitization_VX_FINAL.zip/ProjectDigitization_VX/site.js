



//Added parts for Lab 7//

function getCookie(cname) {
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}

function createCookie() {
    ("shoppingcart", jsonItems, 1);
}



function Checkout() {
    var jsonitems = JSON.stringify(items);
    setCookie("cartitems", jsonitems, 1);
    window.location.href = "checkout.html";


}


var params = new Array();
function queryString() {
    var queryString = window.location.search.replaceAll("?", "").replace(/\+/g, " ");
    var varArray = queryString.split("&");
    for (var i = 0; i < varArray.length; i++) {
        var param = varArray[i].split("=");
        params[param[0]] = param[1];
    }
}

function goHOME() {
    window.location.href = "index.html";
}
