<?php 
    include('functions.php');
    //if not logged in, redirected to login.php
    if (!isLoggedIn()) {
        $_SESSION['msg'] = "You must log in first";
        header('location: login.php');
    }
?>


<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="Our Passion                      For Delicious                      food, hight quality, best recipes, real taste, catering, pizza, salads, desserts, Excellent                      Services &amp; good                      Prices, Our Team, location, follow us, contact form">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Home</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="HomePage.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 2.29.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Merriweather:300,300i,400,400i,700,700i,900,990i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=heading-font">
    
    
    
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "Site2",
		"url": "index.html",
		"sameAs": []
}</script>
    <meta property="og:title" content="Home">
    <meta property="og:type" content="website">
    <meta name="theme-color" content="#ff5126">
    <link rel="canonical" href="index.html">
    <meta property="og:url" content="index.html">
  </head>
  <body class="u-body u-overlap"><header class="u-align-left u-clearfix u-header u-valign-middle u-header" id="sec-ae7a"><div class="u-black u-border-2 u-border-black u-container-style u-expanded-width u-group u-shape-rectangle u-group-1">
        <div class="u-container-layout u-container-layout-1">
          <nav class="u-menu u-menu-one-level u-offcanvas u-menu-1">
            <div class="menu-collapse" style="font-size: 1.875rem; letter-spacing: 0px; text-transform: uppercase; font-weight: 700;">
              <a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-border-no-left u-border-no-right u-border-no-top u-button-style u-custom-left-right-menu-spacing u-custom-padding-bottom u-custom-top-bottom-menu-spacing u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="#">
                <svg><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#menu-hamburger"></use></svg>
                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol id="menu-hamburger" viewBox="0 0 16 16" style="width: 16px; height: 16px;"><rect y="1" width="16" height="2"></rect><rect y="7" width="16" height="2"></rect><rect y="13" width="16" height="2"></rect>
</symbol>
</defs></svg>
              </a>
            </div>
            <div class="u-custom-menu u-nav-container">
              <ul class="u-nav u-spacing-2 u-unstyled u-nav-1"><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="homepage.php" style="padding: 38px 88px;">Home</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="Menu.php" style="padding: 38px 88px;">Menu</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="About-Us.php" style="padding: 38px 88px;">About Us</a>
</li><li class="u-nav-item"><a class="u-active-grey-5 u-border-active-palette-1-base u-border-hover-palette-1-base u-button-style u-hover-grey-10 u-nav-link u-text-active-grey-90 u-text-body-alt-color u-text-hover-grey-90" href="Contact-Us.php" style="padding: 38px 88px;">Contact Us</a>
</li>

<li class="u-nav-item">

<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
			

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="index.php?logout='1'" style="color: red;">Logout</a>
					</small>

				<?php endif ?>

            </div>

            </li>

</ul>
            </div>
            <div class="u-custom-menu u-nav-container-collapse">
              <div class="u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
                <div class="u-sidenav-overflow">
                  <div class="u-menu-close"></div>
                  <ul class="u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2"><li class="u-nav-item"><a class="u-button-style u-nav-link" href="homepage.php" style="padding: 38px 88px;">Home</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Menu.php" style="padding: 38px 88px;">Menu</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="About-Us.php" style="padding: 38px 88px;">About Us</a>
</li><li class="u-nav-item"><a class="u-button-style u-nav-link" href="Contact-Us.php" style="padding: 38px 88px;">Contact Us</a>
</li>

<li class="u-nav-item">

<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>
		<!-- logged in user information -->
		<div class="profile_info">
			

			<div>
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
						<a href="index.php?logout='1'" style="color: red;">Logout</a>
					</small>

				<?php endif ?>

            </div>

            </li>
            
</ul>
                </div>
              </div>
              <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
            </div>
          </nav>
        </div>
      </div></header> 
    <section class="u-clearfix u-image u-shading u-section-1" id="carousel_020b">
      <div class="u-container-style u-expand-resize u-expanded-width u-group u-image u-image-1">
        <div class="u-container-layout u-container-layout-1">
          <img src="images/bd59666e996bb8829ad08ab39512bc92.png" alt="" class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-image u-image-contain u-image-default u-image-2">
          <div class="u-shape u-shape-circle u-white u-shape-1"></div>
          <div class="u-align-center u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-container-style u-group u-group-2">
            <div class="u-container-layout u-valign-middle u-container-layout-2">
              <h1 class="u-text u-text-body-alt-color u-text-1">Project Digitization</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-expanded-width-xl u-section-2" id="carousel_b182">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-align-center u-container-style u-group u-group-1">
          <div class="u-container-layout u-valign-middle u-container-layout-1"><span class="u-icon u-icon-circle u-text-grey-40 u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512.00003 512.00003"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-4855"></use></svg><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512.00003 512.00003" id="svg-4855" class="u-svg-content"><path d="m42.667969 512h290.132812c14.136719 0 25.597657-11.460938 25.597657-25.601562v-426.664063c0-14.140625-11.460938-25.601563-25.597657-25.601563h-290.132812c-23.554688.027344-42.6406252 19.113282-42.667969 42.667969v392.53125c.0273438 23.554688 19.113281 42.640625 42.667969 42.667969zm298.664062-452.265625v426.664063c0 4.714843-3.820312 8.535156-8.53125 8.535156h-247.46875v-25.601563h8.535157c4.710937 0 8.53125-3.820312 8.53125-8.53125 0-4.714843-3.820313-8.535156-8.53125-8.535156h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.53125 0-4.714844-3.820313-8.535157-8.53125-8.535157h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820312 8.53125-8.53125 0-4.714844-3.820313-8.535156-8.53125-8.535156h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.535156 0-4.710938-3.820313-8.53125-8.53125-8.53125h-8.535157v-17.066407h8.535157c4.710937 0 8.53125-3.820312 8.53125-8.535156 0-4.710937-3.820313-8.53125-8.53125-8.53125h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.535157 0-4.710937-3.820313-8.53125-8.53125-8.53125h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.824218 8.53125-8.535156s-3.820313-8.535156-8.53125-8.535156h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.53125 0-4.714844-3.820313-8.535157-8.53125-8.535157h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.53125 0-4.714844-3.820313-8.535156-8.53125-8.535156h-8.535157v-17.066407h8.535157c4.710937 0 8.53125-3.820312 8.53125-8.53125 0-4.714843-3.820313-8.535156-8.53125-8.535156h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820312 8.53125-8.535156 0-4.710938-3.820313-8.53125-8.53125-8.53125h-8.535157v-17.066406h8.535157c4.710937 0 8.53125-3.820313 8.53125-8.535157 0-4.710937-3.820313-8.53125-8.53125-8.53125h-8.535157v-25.601562h247.46875c4.710938 0 8.53125 3.820312 8.53125 8.535156zm-324.265625 17.066406c0-14.140625 11.460938-25.601562 25.601563-25.601562h25.597656v25.601562h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.53125 0 4.714844 3.820312 8.535157 8.535156 8.535157h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820312-8.535156 8.53125 0 4.714844 3.820312 8.535156 8.535156 8.535156h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.535156 0 4.710938 3.820312 8.53125 8.535156 8.53125h8.53125v17.066407h-8.53125c-4.714844 0-8.535156 3.820312-8.535156 8.535156 0 4.710937 3.820312 8.53125 8.535156 8.53125h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.535157 0 4.710937 3.820312 8.53125 8.535156 8.53125h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.824218-8.535156 8.535156s3.820312 8.535156 8.535156 8.535156h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.53125 0 4.714844 3.820312 8.535157 8.535156 8.535157h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.53125 0 4.714844 3.820312 8.535156 8.535156 8.535156h8.53125v17.066407h-8.53125c-4.714844 0-8.535156 3.820312-8.535156 8.53125 0 4.714843 3.820312 8.535156 8.535156 8.535156h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820312-8.535156 8.535156 0 4.710938 3.820312 8.53125 8.535156 8.53125h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.535157 0 4.710937 3.820312 8.53125 8.535156 8.53125h8.53125v17.066406h-8.53125c-4.714844 0-8.535156 3.820313-8.535156 8.535156 0 4.710938 3.820312 8.53125 8.535156 8.53125h8.53125v25.601563h-25.597656c-14.140625 0-25.601563-11.460938-25.601563-25.601563zm0 0"></path><path d="m154.503906 229.65625 3.414063 27.402344 4.265625 34.132812c.535156 4.277344 4.171875 7.484375 8.484375 7.476563h102.398437c4.304688-.003907 7.933594-3.207031 8.464844-7.476563l4.265625-34.132812 3.414063-27.402344c20.25-3.644531 35.003906-21.234375 35.0625-41.808594.058593-20.578125-14.59375-38.253906-34.824219-42.011718 3.71875-26.417969-8.292969-52.578126-30.75-66.976563-22.457031-14.402344-51.242188-14.402344-73.699219 0-22.457031 14.398437-34.46875 40.558594-30.75 66.976563-20.246094 3.738281-34.921875 21.421874-34.863281 42.011718.058593 20.585938 14.835937 38.1875 35.101562 41.808594zm67.363282 51.945312h-43.664063l-2.136719-17.066406h91.597656l-2.132812 17.066406zm-77.832032-111.976562c4.789063-4.8125 11.304688-7.511719 18.097656-7.492188h.972657l.855469.050782c6.425781.476562 12.4375 3.359375 16.835937 8.074218 3.246094 3.300782 8.53125 3.410157 11.914063.25 3.382812-3.164062 3.621093-8.449218.542968-11.90625-5.804687-6.1875-13.324218-10.492187-21.597656-12.367187-.632812-3.195313-.964844-6.441406-.988281-9.699219 0-28.277344 22.921875-51.203125 51.199219-51.203125 28.277343 0 51.199218 22.925781 51.199218 51.203125-.035156 3.261719-.378906 6.515625-1.023437 9.71875-8.273438 1.867188-15.796875 6.171875-21.597657 12.355469-2.171874 2.210937-2.976562 5.421875-2.101562 8.394531.878906 2.972656 3.296875 5.238282 6.320312 5.914063 3.023438.675781 6.179688-.335938 8.238282-2.652344 4.398437-4.714844 10.410156-7.597656 16.835937-8.074219l.855469-.050781h1.007812c9.144532 0 17.59375 4.878906 22.167969 12.800781s4.574219 17.679688 0 25.601563c-4.574219 7.917969-13.023437 12.800781-22.167969 12.800781-.363281.046875-.722656.117188-1.078124.210938-.605469.058593-1.203126.179687-1.78125.367187-.457032.183594-.898438.40625-1.316407.664063-.511719.273437-.996093.601562-1.441406.972656-.371094.359375-.710937.746094-1.015625 1.164062-.796875 1.273438-1.414062 2.652344-1.832031 4.09375l-3.339844 26.648438h-95.863281l-3.335938-26.65625c-.097656-.371094-.21875-.730469-.367187-1.082032-.199219-1.089843-.6875-2.105468-1.414063-2.9375-.332031-.460937-.703125-.886718-1.121094-1.269531-.410156-.339843-.855468-.640625-1.320312-.898437-.9375-.628906-2.027344-1-3.15625-1.066406-.355469-.097657-.71875-.171876-1.085938-.222657-10.355468.003907-19.691406-6.234375-23.65625-15.804687-3.960937-9.566406-1.769531-20.582032 5.558594-27.902344zm0 0"></path><path d="m136.535156 358.398438h17.066406c4.710938 0 8.53125-3.820313 8.53125-8.53125 0-4.714844-3.820312-8.535157-8.53125-8.535157h-17.066406c-4.714844 0-8.535156 3.820313-8.535156 8.535157 0 4.710937 3.820312 8.53125 8.535156 8.53125zm0 0"></path><path d="m307.199219 341.332031h-119.464844c-4.714844 0-8.535156 3.820313-8.535156 8.535157 0 4.710937 3.820312 8.53125 8.535156 8.53125h119.464844c4.714843 0 8.535156-3.820313 8.535156-8.53125 0-4.714844-3.820313-8.535157-8.535156-8.535157zm0 0"></path><path d="m153.601562 409.601562h-17.066406c-4.714844 0-8.535156 3.820313-8.535156 8.53125 0 4.714844 3.820312 8.535157 8.535156 8.535157h17.066406c4.710938 0 8.53125-3.820313 8.53125-8.535157 0-4.710937-3.820312-8.53125-8.53125-8.53125zm0 0"></path><path d="m307.199219 409.601562h-119.464844c-4.714844 0-8.535156 3.820313-8.535156 8.53125 0 4.714844 3.820312 8.535157 8.535156 8.535157h119.464844c4.714843 0 8.535156-3.820313 8.535156-8.535157 0-4.710937-3.820313-8.53125-8.535156-8.53125zm0 0"></path><path d="m136.535156 392.535156h85.332032c4.710937 0 8.53125-3.824218 8.53125-8.535156s-3.820313-8.535156-8.53125-8.535156h-85.332032c-4.714844 0-8.535156 3.824218-8.535156 8.535156s3.820312 8.535156 8.535156 8.535156zm0 0"></path><path d="m307.199219 375.464844h-51.199219c-4.710938 0-8.535156 3.824218-8.535156 8.535156s3.824218 8.535156 8.535156 8.535156h51.199219c4.714843 0 8.535156-3.824218 8.535156-8.535156s-3.820313-8.535156-8.535156-8.535156zm0 0"></path><path d="m443.734375 0c-37.640625 0-68.269531 42.113281-68.269531 93.867188 0 39.304687 17.683594 72.992187 42.667968 86.953124v305.578126c0 14.140624 11.460938 25.601562 25.601563 25.601562 14.136719 0 25.597656-11.460938 25.597656-25.601562v-305.578126c24.988281-13.960937 42.667969-47.648437 42.667969-86.953124 0-51.753907-30.625-93.867188-68.265625-93.867188zm8.53125 486.398438c0 4.714843-3.820313 8.535156-8.53125 8.535156-4.714844 0-8.535156-3.820313-8.535156-8.535156v-299.476563c5.636719 1.082031 11.429687 1.082031 17.066406 0zm5.316406-318.667969-.179687.070312c-8.703125 3.8125-18.601563 3.8125-27.304688 0l-.179687-.070312c-21.554688-9.097657-37.382813-38.722657-37.382813-73.863281 0-42.34375 22.960938-76.800782 51.199219-76.800782 28.234375 0 51.199219 34.457032 51.199219 76.800782 0 35.140624-15.828125 64.765624-37.351563 73.863281zm0 0"></path></svg></span>
            <h3 class="u-text u-text-1">Our Menu</h3>
          </div>
        </div>
        <div class="u-clearfix u-expanded-width-lg u-expanded-width-md u-expanded-width-xl u-expanded-width-xs u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-layout">
            <div class="u-layout-row">
              <div class="u-align-left-lg u-align-left-sm u-align-left-xs u-container-style u-layout-cell u-left-cell u-size-20 u-size-20-md u-layout-cell-1">
                <div class="u-container-layout u-valign-top-md">
                  <h2 class="u-text u-text-grey-70 u-text-2">Meal</h2>
                  <p class="u-text u-text-grey-50 u-text-3">Burger description</p>
                  <img src="images/1200x630.jpg" alt="" class="u-expanded-width u-image u-image-default u-image-1">
                </div>
              </div>
              <div class="u-align-left-lg u-align-left-sm u-align-left-xs u-container-style u-layout-cell u-size-20 u-size-20-md u-layout-cell-2">
                <div class="u-container-layout u-valign-top-md">
                  <h2 class="u-text u-text-grey-70 u-text-4">Beverages</h2>
                  <p class="u-text u-text-grey-50 u-text-5">All kinds of drinks</p>
                  <img src="images/HERO_Worlds_Best_Soda_Bundaberg_shutterstock_679079920.jpg" alt="" class="u-expanded-width u-image u-image-default u-image-2">
                </div>
              </div>
              <div class="u-align-left-lg u-align-left-sm u-align-left-xs u-container-style u-layout-cell u-right-cell u-size-20 u-size-20-md u-layout-cell-3">
                <div class="u-container-layout u-valign-top-md">
                  <h2 class="u-text u-text-grey-70 u-text-6">Dessert</h2>
                  <p class="u-text u-text-grey-50 u-text-7">Icecream</p>
                  <img src="images/b81dc61f5cc588090e947e2da8347594.jpeg" alt="" class="u-expanded-width u-image u-image-default u-image-3">
                </div>
              </div>
            </div>
          </div>
        </div>
        <a href="Menu.php" class="u-border-2 u-border-palette-2-base u-btn u-btn-round u-button-style u-hover-grey-75 u-none u-radius-6 u-text-body-color u-text-hover-white u-btn-1">View Menu</a>
      </div>
    </section>
    <section class="u-clearfix u-image u-shading u-valign-top u-section-3" id="carousel_d423">
      <div class="u-container-style u-expand-resize u-expanded-width u-group u-image u-image-1">
        <div class="u-container-layout u-container-layout-1">
          <img src="images/bd59666e996bb8829ad08ab39512bc92.png" alt="" class="u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-image u-image-contain u-image-default u-image-2">
          <div class="u-shape u-shape-circle u-white u-shape-1"></div>
        </div>
      </div>
      <div class="u-align-center u-border-no-bottom u-border-no-left u-border-no-right u-border-no-top u-container-style u-group u-group-2">
        <div class="u-container-layout u-valign-middle u-container-layout-2">
          <h1 class="u-text u-text-body-alt-color u-text-1">Excellent<br> Services &amp; good<br> Prices
          </h1>
        </div>
      </div>
    </section>
    <section class="u-clearfix u-expanded-width-xl u-section-4" id="sec-3ced">
      <div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-clearfix u-expanded-width u-gutter-30 u-layout-wrap u-layout-wrap-1">
          <div class="u-gutter-0 u-layout">
            <div class="u-layout-row">
              <div class="u-size-60">
                <div class="u-layout-col">
                  <div class="u-align-center-lg u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-1">
                    <div class="u-container-layout u-valign-top u-container-layout-1">
                      <h2 class="u-text u-text-grey-70 u-text-1">Location</h2>
                      <p class="u-text u-text-2">700 East Seventh Street Saint Paul, MN 55106-5000</p>
                    </div>
                  </div>
                  <div class="u-align-left u-container-style u-layout-cell u-left-cell u-size-30 u-layout-cell-2">
                    <div class="u-container-layout u-valign-middle-lg u-valign-top-md u-container-layout-2">
                      <h2 class="u-text u-text-grey-70 u-text-3">follow us</h2>
                      <div class="u-social-icons u-spacing-20 u-text-grey-80 u-social-icons-1">
                        <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-facebook u-social-type-fill u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112.2 112.2"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-05cd"></use></svg><svg x="0px" y="0px" viewBox="0 0 112.2 112.2" style="enable-background:new 0 0 112.2 112.2;" xml:space="preserve" id="svg-05cd" class="u-svg-content"><path d="M56.1,0C25.1,0,0,25.1,0,56.1c0,31,25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1C112.2,25.1,87.1,0,56.1,0z M71.6,34.3h-8.2c-1.3,0-3.2,0.7-3.2,3.5v7.6h11.3l-1.3,12.9h-10V95H45V58.3h-7.2V45.4H45v-8.3c0-6,2.8-15.3,15.3-15.3l11.2,0V34.3z "></path></svg></span>
                        </a>
                        <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-twitter u-social-type-fill u-icon-2"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112.2 112.2"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-ed78"></use></svg><svg x="0px" y="0px" viewBox="0 0 112.2 112.2" style="enable-background:new 0 0 112.2 112.2;" xml:space="preserve" id="svg-ed78" class="u-svg-content"><path d="M56.1,0C25.1,0,0,25.1,0,56.1s25.1,56.1,56.1,56.1s56.1-25.1,56.1-56.1S87.1,0,56.1,0z M83.8,47.3 c0,0.6,0,1.2,0,1.7c0,17.7-13.5,38.2-38.2,38.2c-7.6,0-14.6-2.2-20.6-6c1,0.1,2.1,0.2,3.2,0.2c6.3,0,12.1-2.1,16.7-5.7 c-5.9-0.1-10.8-4-12.5-9.3c0.8,0.2,1.7,0.2,2.5,0.2c1.2,0,2.4-0.2,3.5-0.5c-6.1-1.2-10.8-6.7-10.8-13.1c0-0.1,0-0.1,0-0.2 c1.8,1,3.9,1.6,6.1,1.7c-3.6-2.4-6-6.5-6-11.2c0-2.5,0.7-4.8,1.8-6.7c6.6,8.1,16.5,13.5,27.6,14c-0.2-1-0.3-2-0.3-3.1 c0-7.4,6-13.4,13.4-13.4c3.9,0,7.3,1.6,9.8,4.2c3.1-0.6,5.9-1.7,8.5-3.3c-1,3.1-3.1,5.8-5.9,7.4c2.7-0.3,5.3-1,7.7-2.1 C88.7,43,86.4,45.4,83.8,47.3z"></path></svg></span>
                        </a>
                        <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-instagram u-social-type-fill u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112.2 112.2"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-556d"></use></svg><svg x="0px" y="0px" viewBox="0 0 112.2 112.2" style="enable-background:new 0 0 112.2 112.2;" xml:space="preserve" id="svg-556d" class="u-svg-content"><path d="M56.1,0C25.1,0,0,25.1,0,56.1c0,31,25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1C112.2,25.1,87.1,0,56.1,0z M90.6,73.4c0,9.6-7.8,17.5-17.5,17.5H38.6c-9.6,0-17.5-7.9-17.5-17.6V38.8c0-9.6,7.8-17.5,17.5-17.5h34.5c9.6,0,17.5,7.8,17.5,17.5 V73.4z"></path><path d="M73.1,28.9H38.6c-5.4,0-9.9,4.4-9.9,9.9v34.5c0,5.4,4.4,9.9,9.9,9.9h34.5c5.4,0,9.9-4.4,9.9-9.9V38.8 C83,33.4,78.6,28.9,73.1,28.9z M55.9,74C46,74,38,66,38,56.1c0-9.9,8-17.9,17.9-17.9c9.9,0,17.9,8,17.9,17.9 C73.8,66,65.8,74,55.9,74z M74.3,41.9c-2.3,0-4.2-1.9-4.2-4.2s1.9-4.2,4.2-4.2c2.3,0,4.2,1.9,4.2,4.2S76.6,41.9,74.3,41.9z"></path><path d="M55.9,45.8c-5.7,0-10.4,4.6-10.3,10.3c0,5.7,4.6,10.3,10.3,10.3s10.3-4.6,10.3-10.3 C66.2,50.4,61.6,45.8,55.9,45.8z"></path></svg></span>
                        </a>
                        <a class="u-social-url" target="_blank" href=""><span class="u-icon u-icon-circle u-social-google u-social-type-fill u-icon-4"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112.2 112.2"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-af15"></use></svg><svg x="0px" y="0px" viewBox="0 0 112.2 112.2" style="enable-background:new 0 0 112.2 112.2;" xml:space="preserve" id="svg-af15" class="u-svg-content"><path d="M56.1,0C25.1,0,0,25.1,0,56.1s25.1,56.1,56.1,56.1c31,0,56.1-25.1,56.1-56.1S87.1,0,56.1,0z M60.1,73.8 c-5.7,7.4-16.3,9.5-24.9,6.6c-9.1-3-15.8-12.2-15.6-21.9c-0.5-11.9,10-22.9,21.9-23.1c6.1-0.5,12,1.8,16.6,5.7 c-1.9,2.1-3.8,4.1-5.9,6.1c-4.1-2.5-8.9-4.3-13.7-2.7c-7.6,2.2-12.3,11.2-9.4,18.7c2.3,7.8,11.8,12.1,19.3,8.8 c3.9-1.4,6.4-4.9,7.5-8.8c-4.4-0.1-8.8,0-13.3-0.2c0-2.6,0-5.2,0-7.9c7.4,0,14.7,0,22.1,0C65.2,61.8,64.2,68.7,60.1,73.8z M92.3,61.9c-2.2,0-4.4,0-6.6,0c0,2.2,0,4.4,0,6.6c-2.2,0-4.4,0-6.6,0c0-2.2,0-4.4,0-6.6c-2.2,0-4.4,0-6.6,0c0-2.2,0-4.4,0-6.6 c2.2,0,4.4,0,6.6,0c0-2.2,0-4.4,0.1-6.6c2.2,0,4.4,0,6.6,0c0,2.2,0,4.4,0,6.6c2.2,0,4.4,0,6.6,0C92.3,57.5,92.3,59.7,92.3,61.9z"></path></svg></span>
                        </a>
                      </div>
                      <p class="u-text u-text-4">©2020 Privacy policy</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    
    
    
    
  </body>
</html>