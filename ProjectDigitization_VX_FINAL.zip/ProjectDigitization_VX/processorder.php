<?php

include 'payment.php';

?>

<!DOCTYPE html>

<html>
 
<head>
    <title>Review Your Info</title>
    <link rel="stylesheet" href="styles.css">
    <?php
            
            echo $title;
            echo $price;

            ?>
    
    <script>
        window.onload = (event) => {
            queryString();
            var title = document.getElementById("title");
            var name = document.getElementById("user");
            var address = document.getElementById("address");
            var phone = document.getElementById("phone");
            var cc = document.getElementById("ccnumber");

          
            title.innerHTML = "Title: "  + params["fname"] + " " + params["lname"];
            name.innerHTML = "User: "  + params["fname"] + " " + params["lname"];
            address.innerHTML = "Address: " + params["StreetAddress"] + "<br>" + params["City"] + ", " + params["State"] +
                " " + params["Zip"];
            phone.innerHTML = "Phone Number: " + params["PhoneNumber"];
            cc.innerHTML = "Credit Card Number: " + params["CreditCardNumber"];
        }
    </script>

</head>

<body>

    <div class="header">
        <p>Review Your Info</p>
      </div>


            <table class="cartlist" id="cartlist">
            </table>


            <div class = "test">
                <div id="user"></div>
                <div id="address"></div>
                <div id="phone"></div>
                <div id="ccnumber"></div>
                <button onclick="goHOME()">Process Order</button>

                </form>
            </div>

            <script>
                function GoHome() {
                    window.location = "../index.html";
                }
            </script>
            <script src="site.js"></script>



</body>


</html>