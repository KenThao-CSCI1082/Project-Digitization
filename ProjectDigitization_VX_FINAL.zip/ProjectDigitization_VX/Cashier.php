<?php
include('functions.php');
include('db.php');


if (!isCashier()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: login.php");
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
	.header {
		background: black;
	}
	button[name=register_btn] {
		background: #003366;
	}
	</style>
</head>
<body>

	<div class="header">
		<h2>Cashier - Home Page</h2>
	</div>
	<div class="content">
		<!-- notification message -->
		<?php if (isset($_SESSION['success'])) : ?>
			<div class="error success" >
				<h3>
					<?php 
						echo $_SESSION['success']; 
						unset($_SESSION['success']);
					?>
				</h3>
			</div>
		<?php endif ?>

		<!-- logged in user information -->
		<div class="profile_info">
			<img src="images/pepe.jpg"  >
            
			<div>

            
				<?php  if (isset($_SESSION['user'])) : ?>
					<strong><?php echo $_SESSION['user']['username']; ?></strong>

					<small>
						<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['user_type']); ?>)</i> 
						<br>
                        
                    
						 - 
                        <a href="Cashier.php?logout='1'" style="color: red;">Logout</a>
                        
					</small>

				<?php endif ?>
<br><br>


<?php 
$sql = "SELECT * FROM food ORDER BY orderID DESC;";
$result = mysqli_query($conn, $sql);
?>


<table align="center" border="1px" style="width:600px; line-height:30px;">

		<tr>
				<th colspan="5"><h2>View Orders</h2></th>
		</tr>
		<tr>
			<th style="width:80px;"> Order # </th>
			<th> First Name </th>
			<th> Last Name </th>
			<th> Type </th>
			<th> Price </th>

		</tr>	

		<?php
			while($row = mysqli_fetch_assoc($result))
			{
				
		?>

				<tr>
				
					<td align="center"><?php echo $row['orderID'];?></td>
					<td align="center"><?php echo $row['fname'];?></td>
					<td align="center"><?php echo $row['lname'];?></td>
					<td align="center"><?php echo $row['type'];?></td>
					<td align="center"><?php echo "$"; echo $row['price'];?></td>
					
				</tr>
				
			<?php
			}
			?>
		</table>

		

			</div>
		</div>
	</div>
</body>
</html>
