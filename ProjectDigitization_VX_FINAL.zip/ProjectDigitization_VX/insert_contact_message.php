<?php

$name = $_POST['name'];
$emailMessage = $_POST['emailMessage'];
$message = $_POST['message'];


$sql = "INSERT INTO message (Name, Email, Message)

 VALUES ('$name', '$emailMessage', '$$message')";

?>

<html>
    <h4 align="center">  THIS IS A NEW ERA<h4> 
    </html>