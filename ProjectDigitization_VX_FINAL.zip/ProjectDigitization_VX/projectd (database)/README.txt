This is a database called projectd

Simply drag and drop this foler into xampp/mysql/data, delete "(Database)"
from the name of the folder

Useful Commands:

use projectd;
show tables;
select * from users;
