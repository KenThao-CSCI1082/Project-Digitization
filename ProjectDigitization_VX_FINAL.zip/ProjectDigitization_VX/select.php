<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projectd";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

 // Check connection

 if ($conn->connect_error) {

    die("Connection failed: " . $conn->connect_error);
}


 
$sql = "SELECT * FROM food;";
$result = mysqli_query($conn, $sql);

$resultCheck = mysqli_num_rows($result);
if ($resultCheck > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
        echo $row['fname'];
    }
}

 
if ($conn->query($sql) === TRUE) {
    echo "";
    
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();


?>
