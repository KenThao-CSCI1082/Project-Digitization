<?php

include 'db.php';

$fname = $_POST['fname'];
$lname = $_POST['lname'];
$StreetAddress = $_POST['StreetAddress'];
$City = $_POST['City'];
$State = $_POST['State'];
$Zip = $_POST['Zip'];
$type = 'Knight Meal';
$price = 13.58;




 
$sql = "INSERT INTO food (fname, lname, StreetAddress, City, State, Zip, type, price)

 VALUES ('$fname', '$lname', '$StreetAddress', '$City', '$State', '$Zip', '$type', '$price')";



 



?>


<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Receipt</title>
    
    <link rel="stylesheet" href="Menu.css" media="screen">
    <link rel="stylesheet" href="nicepage.css" media="screen">

    <style>
    .invoice-box {
        max-width: 800px;
        margin: auto;
        padding: 30px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 16px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }
    
    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
    }
    
    .invoice-box table td {
        padding: 5px;
        vertical-align: top;
    }
    
    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }
    
    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }
    
    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }
    
    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
    }
    
    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }
    
    .invoice-box table tr.item td{
        border-bottom: 1px solid #eee;
    }
    
    .invoice-box table tr.item.last td {
        border-bottom: none;
    }
    
    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }
    
    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }
        
        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }
    
    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }
    
    .rtl table {
        text-align: right;
    }
    
    .rtl table tr td:nth-child(2) {
        text-align: left;
    }
    </style>
</head>

<body>
    <div class="invoice-box">
        <table cellpadding="0" cellspacing="0">
            <tr class="top">
                <td colspan="2">
                    <table>
                        <tr>
                            <td class="title">
                                <img src="images/pepe_punch.jpg" style="width:100%; max-width:150px;">
                               <h4 align = "left"> Project
                                Digitization <h4>
                            </td>
                            
                            <td>
                                <b>Group Members</b><br>
                                KenThao<br>
                                Clayton Miller <br>
                                Obsan Maskalo <br>
                                Skyler Jensen <br>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="information">
                <td colspan="2">
                    <table>
                        <tr>
                            <td>
                                Metropolitan State University<br>
                                700 East Street<br>
                                Saint Paul, MN 55106
                            </td>
                            
                            
                        </tr>
                    </table>
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Payment Method
                </td>
                
                <td>
                    Card Type
                </td>
            </tr>
            
            <tr class="details">
                <td>
                    Card
                </td>
                
                <td>
                    Debit
                </td>
            </tr>
            
            <tr class="heading">
                <td>
                    Item
                </td>
                
                <td>
                    Price
                </td>
            </tr>
            
            <tr class="item">
                <td>
                    <?php echo $type; ?>
                </td>
                
                <td>
                    <?php echo"$"; echo $price; ?>
                </td>
            </tr>
            
            <tr class="total">
                <td></td>
                
                <td>
                   Total: <?php echo"$"; echo $price; ?>
                </td>

                <tr class="heading">
                <td>
                    Customer Info
                </td>
                
                <td>
                    
                </td>
            </tr>
            

            <tr class="details">
                <td>
                    Name:
                </td>
                
                <td>
                    <?php echo $fname; echo " "; echo $lname?>
                </td>
            </tr>

        

            </tr>
        </table>
    </div>
    <br></br>
    <div align = 'center'> <button onClick="window.print()">Print</button> </div>
    <div align='center' >
        <a style="text-align: center; width:100%; max-width:300px;" href="homepage.php" align = "center"class="u-border-2 u-border-black u-btn u-button-style u-hover-black u-none u-text-black u-text-hover-white u-btn-1">Go Home</a>
    </div>
</body>
</html>