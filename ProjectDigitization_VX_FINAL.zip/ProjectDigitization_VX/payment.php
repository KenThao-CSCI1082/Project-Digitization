

<!DOCTYPE html>
<html>

<head>
    <title>Payment Page</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
</head>

<body>


    <div>

        <div class="header">
            <p>Billing & Payment</p>
          </div>


        <?php
        
        $title = "Commoner's Meal";
        $price = 11.59;
        $des = "Full Course Meal: Onions, Beef Patty, Lettuce, Tomatoes,
        Ketchup, and Mayo";

        
        ?>

        <form action="processorder.php" onsubmit="return validate()" name="CheckoutForm" method="GET">
            Type: Commoner Meal <br> </br>
            Price: $11.59 <br></br>
            Description: Full Course Meal: Onions, Beef Patty, Lettuce, Tomatoes,
            Ketchup, and Mayo <br> <br>

            First name: <input type="text" name="fname" id="fname" size="25" required max="50">
            <label id="fnameError" class="error"></label>
            <br>

            Last name: <input type="text" name="lname" id="lname" size="25" required max="50">
            <label id="lnameError" class="error"></label><br>

            Street Address: <input type="text" name="StreetAddress" id="StreetAddress" size="25" required
                max="50">
            <label id="StreetAddresError" class="error"></label><br>

            City: <input type="text" name="City" id="City" size="25" required max="50">
            <label id="CityError" class="error"></label><br>

            State: <input type="text" name="State" id="State" size="25" required max="50">
            <label id="StateError" class="error"></label><br>

            Zip: <input type="text" name="Zip" id="Zip" size="25" required max="50">
            <label id="ZipError" class="error"></label><br>

            Phone Number: <input type="text" name="PhoneNumber" id="PhoneNumber" size="25" requiredmax="50">
            <label id="PhoneNumberError" class="error"></label><br>


            Credit card Number(starting with 51-55, length is 16.): <input type="text" name="CreditCardNumber" id="CreditCardNumber" size="25"
                required max="50">
            <label id="CreditCardNumberError" class="error"></label><br>


            <button type="submit">Confirm Order</button>

        </form>
    </div>



    <script>
        function GoHome() {
            window.location = "../index.html";
        }
    </script>

    <script>
        function validate() {
            var fname = $("#fname").val();
            var lname = $("#lname").val();
            var StreetAddress = $("#StreetAddress").val();
            var City = $("#City").val();
            var State = $("#State").val();
            var Zip = $("#Zip").val();
            var PhoneNumber = $("#PhoneNumber").val();
            var CreditCardNumber = $("#CreditCardNumber").val();

            var errors = 0;

            vvfname = checktext(fname);
            if (vvfname.status == "Error") {
                $('#fnameError').text(vvfname.message);
                errors++;
            }
            vvlname = checktext(lname);
            if (vvlname.status == "Error") {
                $('#lnameError').text(vvlname.message);
                errors++;

            }

            vvCity = checktext(City);
            if (vvCity.status == "Error") {
                $('#CityError').text(vvCity.message);
                errors++;
            }

            vvState = checktext(State);
            if (vvState.status == "Error") {
                $('#StateError').text(vvState.message);
                errors++;
            }

            vvZip = validateZipCode(Zip);
            if (vvZip.status == "Error") {
                $('#ZipError').text(vvZip.message);
                errors++;
            }


            vvPhoneNumber = validatePhoneNumber(PhoneNumber);
            if (vvPhoneNumber.status == "Error") {
                $('#PhoneNumberError').text(vvPhoneNumber.message);
                errors++;
            }
    
            vvCreditCardNumber = validateCreditCardNumber(CreditCardNumber);
            if (vvCreditCardNumber.status == "Error") {
                $('#CreditCardNumberError').text(vvCreditCardNumber.message);
                errors++;
            }

            return errors == 0;


        }




        function checktext(inputtext) {
            var letters = /^[A-Za-z]+$/;
            if (!inputtext.match(letters)) {
                return {
                    "status": "Error",
                    "message": "Cannot be numeric!"
                };
            }
            else if (inputtext === "") {
                return {
                    "status": "Error",
                    "message": "Cannot be blank!"
                };
            }
            else {
                return {
                    "status": "success",
                    "message": ""
                };
            }
        }

        function validateZipCode(inputtext) {
            var Zip = /^\d{5}$|^\d{5}-\d{4}$/;
            if (!inputtext.match(Zip)) {
                return {
                    "status": "Error",
                    "message": "Must be 5 digits, not valid"
                };
            }
            else if (inputtext === "") {
                return {
                    "status": "Error",
                    "message": "Cannot be blank!"
                };
            }
            else {
                return {
                    "status": "success",
                    "message": ""
                };
            }
        }


        function validatePhoneNumber(inputtext) {
            var PhoneNumber = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
            if (!inputtext.match(PhoneNumber)) {
                return {
                    "status": "Error",
                    "message": "Not a valid phone number"
                };
            }
            else if (inputtext === "") {
                return {
                    "status": "Error",
                    "message": "Cannot be blank!"
                };
            }
            else {
                return {
                    "status": "success",
                    "message": ""

                };
            }
        }

        function validateCreditCardNumber(inputtext) {
            var CreditCardNumber = /^(?:5[1-5][0-9]{14})$/;
            if (!inputtext.match(CreditCardNumber)) {
                return {
                    "status": "Error",
                    "message": "Not a valid Credit Card number"
                };
            }
            else if (inputtext === "") {
                return {
                    "status": "Error",
                    "message": "Cannot be blank!"
                };
            }
            else {
                return {
                    "status": "success",
                    "message": ""

                };
            }
        }
    </script>

</body>





</html>